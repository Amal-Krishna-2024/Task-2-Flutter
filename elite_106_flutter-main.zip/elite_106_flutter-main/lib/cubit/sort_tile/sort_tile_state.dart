part of 'sort_tile_cubit.dart';

class SortTileState {
  bool selected;

  SortTileState({
    required this.selected,
  });
}
