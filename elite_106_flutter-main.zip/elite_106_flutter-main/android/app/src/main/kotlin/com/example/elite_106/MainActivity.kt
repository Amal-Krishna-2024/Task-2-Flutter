package com.example.elite_106

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
